----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

LegacyRunebookLoader = {}

function LegacyRunebookLoader.Initialize()

		GGManager.WindowName[89] = "LEGACY_Runebook_GUMP"

end

function LegacyRunebookLoader.ReloadSettings()
	
		GGManager.WindowName[89] = "LEGACY_Runebook_GUMP"

end
